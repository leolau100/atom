# 微信发布工作流 · 详细参考

本文档是 `wechat-article-publish` skill 的实现细节与代码参考。SKILL.md 只讲流程与坑位，这里给可复用的具体代码。

---

## A. 渲染驱动（ocean 主题 → wf.html）

用 Playwright 打开 `render-harness.html`（带 query 参数自动渲染并回存），等待 `wf.html` 生成。

```python
# render_driver.py 思路
from playwright.sync_api import sync_playwright
import time, os

HARNESS = "/Users/liulei/WorkBuddy/2026-08-30-14-40-45/NiceWechatArticle/render-harness.html"
MD = "/Users/liulei/Product/WeChatArticle/2026/09/<slug>.md"
WF = "/Users/liulei/WorkBuddy/2026-08-30-14-40-45/NiceWechatArticle/wf.html"

url = f"{HARNESS}?theme=ocean&md={MD}&save=/__save"
with sync_playwright() as p:
    b = p.chromium.launch(channel="chrome")          # 用系统 Chrome，避免下载
    pg = b.new_page()
    pg.goto(url, wait_until="networkidle")
    # harness 自动 POST 到 render_server 写 wf.html；轮询产物
    for _ in range(30):
        if os.path.exists(WF) and os.path.getsize(WF) > 1000:
            break
        time.sleep(1)
    b.close()
```

**渲染后务必校验产物**：
```bash
WF=.../NiceWechatArticle/wf.html
grep -o 'theme-ocean' "$WF" | head -1
grep -oE '<h[23][^>]*style="[^"]*background[^"]*"' "$WF" | wc -l   # 应 >0
grep -oE '.{8}<img.{6}' "$WF" | head -3                              # 图应在 <p> 内
```

> 注意：本 skill 仅用 ocean 主题（与已发 FIWARE 视觉统一）。若文章 `.md` 里图片已是内联 base64（如 qslave），照常可渲染。

---

## B. publish.py 关键结构（位于 `/Users/liulei/Product/01_PubWechatFile/publish.py`）

常量（已迁移到持久目录，避免 `/tmp` 重启清空登录态）：
```python
PROFILE = "/Users/liulei/Product/01_PubWechatFile/.publish_profile"   # 持久登录态
WF      = "/Users/liulei/WorkBuddy/2026-08-30-14-40-45/NiceWechatArticle/wf.html"
IMG_DIR = "/Users/liulei/Product/01_PubWechatFile/.imgs"
TITLE   = "..."   # 默认 FIWARE 标题
AUTHOR  = "DoublePoint"
SOURCE  = "个人观点，仅供参考"
```

启动会话（用系统 Chrome 持久上下文 + 授权剪贴板）：
```python
ctx = p.chromium.launch_persistent_context(
    user_data_dir=PROFILE, headless=False, channel="chrome",
    args=["--no-sandbox", "--disable-setuid-sandbox"])
ctx.grant_permissions(["clipboard-read", "clipboard-write"])
```

---

## C. 粘贴逻辑（含「继续插入」处理）—— 核心代码

**务必保留以下形态**；`insertHTML` 兜底已移除。

```python
def activate_chrome():
    """AppleScript 把 Google Chrome 置前，保证剪贴板粘贴可用。"""
    for name in ("Google Chrome", "Chrome"):
        try:
            subprocess.run(["osascript", "-e",
                f'tell application "{name}" to activate'], timeout=5, check=False)
            return
        except Exception:
            continue

def cursor_to_end():
    edit.evaluate("""() => {
        const els = document.querySelectorAll('div.ProseMirror');
        const el = els[els.length-1]; el.focus();
        const s = window.getSelection(); const r = document.createRange();
        r.selectNodeContents(el); r.collapse(false);
        s.removeAllRanges(); s.addRange(r);
    }""")

def _click_continue_insert():
    """微信「内容结构检测」对话框的「继续插入」按钮：点它才保留内联样式。"""
    try:
        edit.locator(
            ".weui-desktop-dialog button:has-text('继续插入')"
        ).first.click(timeout=3000)
        log("[INFO] clicked 「继续插入」 → 微信 paste 处理器已确认，样式保留")
        edit.wait_for_timeout(3000)
        return True
    except Exception:
        return False

def paste_text(frag):
    # 真实剪贴板粘贴（走微信 paste 处理器，保留 background 等样式）
    edit.evaluate("""async (html) => {
        const plain = html.replace(/<[^>]+>/g, ' ');
        await navigator.clipboard.write([new ClipboardItem({
            'text/html': new Blob([html], {type:'text/html'}),
            'text/plain': new Blob([plain], {type:'text/plain'})
        })]);
    }""", frag)
    activate_chrome()                       # 坑3：强制窗口前台
    edit.wait_for_timeout(800)
    cursor_to_end()
    cdp.send("Input.dispatchKeyEvent", {    # CDP 派发 Cmd+V
        "type": "keyDown", "modifiers": 4, "key": "v", "code": "KeyV",
        "windowsVirtualKeyCode": 86, "commands": ["paste"]})
    cdp.send("Input.dispatchKeyEvent", {
        "type": "keyUp", "modifiers": 4, "key": "v", "code": "KeyV",
        "windowsVirtualKeyCode": 86})
    edit.wait_for_timeout(3500)
    _click_continue_insert()                # 坑1：弹框必须点「继续插入」
    st = body_stats()
    if st["len"] < 200:
        log("[FAIL] body still empty after real paste + 继续插入")
        return 'empty'
    return 'ok'
```

`body_stats()`（判断粘贴是否成功的依据）：
```python
def body_stats():
    return edit.evaluate("""() => {
        let els = Array.from(document.querySelectorAll('div.ProseMirror'));
        let el = els[els.length-1];
        return {img: el.querySelectorAll('img').length,
                mmbiz: el.querySelectorAll('img[src*=mmbiz]').length,
                h2: el.querySelectorAll('h2').length,
                footer: el.textContent.includes('往期推荐'),
                len: el.textContent.length};
    }""")
```

**图片占位符上传**（在 `paste_text` 之后执行）：
```python
# 1) 导出 base64 图为本地文件
os.makedirs(IMG_DIR, exist_ok=True)
srcs = re.findall(r'src="data:image/[^"]+"', html)
for i, s in enumerate(srcs):
    b64 = s.split('base64,')[1].rstrip('"')
    Image.open(io.BytesIO(base64.b64decode(b64))).convert('RGB').save(
        os.path.join(IMG_DIR, f'img{i:02d}.png'), 'PNG')
# 2) 用 %%IMG{i}%% 占位替换 <p><img></p>
# 3) 逐个：选中占位符文本 → input[type=file].set_input_files → 删除占位符
```

---

## D. 发布后重命名（WeChatArticle 仓库）

```bash
cd /Users/liulei/Product/WeChatArticle
git mv "2026/09/<slug>.md"  "2026/09/<slug> （YYYY-M-D日发布，YYYY-M-D日上线）.md"
git mv "2026/09/<slug>.html" "2026/09/<slug> （YYYY-M-D日发布，YYYY-M-D日上线）.html"
git add -A
git commit -q -m "chore: <slug> 发布后重命名(加发布/上线日期后缀)"
git push origin main
```
> 后缀示例（9-5 发布）：` （2026-9-5日发布，2026-9-6日上线）`。`publish.py` 不负责此步。

---

## E. 发布日志解读（看 `/tmp/publish.log`）

成功标志（以 qslave 第三次发布为例）：
```
[INFO] clicked 「继续插入」 → 微信 paste 处理器已确认，样式保留
[INFO] paste via real clipboard: len=3723 h2=8 img=0
[INFO] heading bgs: ["rgba(0, 119, 182, 0.08)", ... ×13]   # 全部标题背景保留
[OK] cover set: url("https://mmbiz.qpic.cn/...")
[OK] original declared
[OK] source set
[DONE]
```

失败信号：
- `real paste empty, fallback insertHTML` → 旧逻辑（已删除）残留，或焦点问题。
- `heading bgs: []` → 背景被洗，检查是否走了 insertHTML / 是否点了「继续插入」。
- `original declare failed ... intercepts pointer events` → 弹框未消失就执行后续步骤，确保 `_click_continue_insert()` 后等待足够。

---

## F. 经验要点（跨项目可复用）

1. 微信粘贴 HTML 后**必先处理「内容结构检测」弹框**，点「继续插入」才保留样式；不点就拦截。
2. 禁用 `execCommand('insertHTML')` 作为粘贴兜底（洗样式）。
3. 真实剪贴板粘贴必须保证 Chrome 前台焦点（AppleScript + bring_to_front）。
4. 图片用真实文件上传，避开 base64 合成粘贴风控。
5. 发布后源文件加「(发布,上线)」日期后缀并提交（既有约定）。
6. 草稿箱 SPA 导航不稳定，重复草稿交用户手动清理。
