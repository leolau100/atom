---
name: wechat-article-publish
description: "Automate publishing Markdown articles to the WeChat Official Account draft box. Covers NiceWechatArticle ocean-theme rendering, Playwright system Chrome paste into the WeChat editor, handling the WeChat content-structure-check dialog (must click 继续插入 to keep background-color styles), uploading images as real files to bypass base64 paste risk-control, and the post-publish filename date-suffix convention. Use this skill when the user wants to publish an article to WeChat, automate pasting into the WeChat editor, or when WeChat-stripped styles such as missing background colors are reported."
agent_created: true
---

# 微信公众号文章自动化发布

把 Markdown 文章渲染成 ocean 主题 HTML，并通过 Playwright + 系统 Chrome 自动化粘贴到微信公众号编辑器的草稿箱，发布完成后按约定重命名源文件。

## 何时使用

- 用户要求「把某篇文章发到微信公众号 / 发布到微信草稿」。
- 需要自动化把 HTML 拷贝进微信编辑器（避免手工粘贴的重复劳动）。
- 微信内文章**背景色 / 内联样式丢失**——这几乎总是粘贴方式不对，参考下方「关键坑位」。
- 文章在 WeChatArticle 仓库发布后需要**加日期后缀重命名**。

## 三个仓库/目录约定

| 用途 | 路径 |
|---|---|
| 文章源（`.md`/`.html`） | `/Users/liulei/Product/WeChatArticle/2026/MM/`（git 仓库 `git@github.com:leolau100/WeChatArticle.git`） |
| 渲染器（NiceWechatArticle） | `/Users/liulei/WorkBuddy/2026-08-30-14-40-45/NiceWechatArticle/`（含 `render-harness.html`、`render_server.py`、`themes/ocean.css`） |
| 发布器 `publish.py` | `/Users/liulei/Product/01_PubWechatFile/`（git 仓库 `git@github.com:leolau100/WeChatPublish.git`） |

> 渲染产物固定写到 `NiceWechatArticle/wf.html`，`publish.py` 默认读取它。

## 标准流程

### 1. 渲染（ocean 主题）

用 `render-harness.html` 把目标 `.md` 渲染成 `wf.html`（图片内联为 base64，标题带内联 `background-color: rgba(0,119,182,0.08)`）：

```
render-harness.html?theme=ocean&md=<md绝对路径>&save=/__save
```

它会 POST 渲染结果到 `render_server.py` 并写入 `wf.html`。校验产物：
- `grep 'theme-ocean'` 应存在，且 `h2/h3` 内联 `style` 含 `background-color`。
- 图片应包在 `<p><img></p>` 内（发布脚本的占位符替换只认此结构）。

参考驱动脚本写法见 `references/publish_workflow.md`。

### 2. 发布（`publish.py`）

脚本已参数化：
```
python3 publish.py --title "<文章标题>" [--html wf.html] [--author DoublePoint] [--source "个人观点，仅供参考"]
```
脚本自动完成：登录（持久化登录态，无需重扫）→ 打开新文章编辑器 → 填标题 → 整篇粘贴 HTML → 真实文件上传图片 → 设封面（正文第一张）→ 文字原创 → 创作来源 → 存草稿。

### 3. 发布后重命名（重要约定）

文章成功发布后，**必须**把 WeChatArticle 仓库里的源文件重命名加后缀，否则与既有约定不一致：
```
git mv "YYYY-MM-DD-xxx.md" "YYYY-MM-DD-xxx （YYYY-M-D日发布，YYYY-M-D日上线）.md"
git mv "YYYY-MM-DD-xxx.html" "YYYY-MM-DD-xxx （YYYY-M-D日发布，YYYY-M-D日上线）.html"
git add -A && git commit -m "chore: <slug> 发布后重命名(加发布/上线日期后缀)"
git push origin main
```
后缀里的「发布」取当天、「上线」取次日（如今天 9-5 发布 → `2026-9-5日发布，2026-9-6日上线`）。`publish.py` 不负责这步，需另行执行。

## 关键坑位（核心经验）

### 坑 1：粘贴后必须点击「继续插入」 ⚠️ 最重要

微信在 Cmd+V 真实粘贴 HTML 后会弹出 **「内容结构检测」** 对话框（标题"内容结构检测"，列出 `darkmode-low-contrast` 等风险），提供「取消」和绿色「继续插入」按钮。

- **只有点击「继续插入」，微信的 paste 处理器才会真正把 HTML 写入编辑器并保留 `background-color` 等内联样式。**
- 不点 → 内容被拦截，`body_stats()` 读到接近空，进而误判"粘贴失败"。
- 实现：粘贴后主动 `edit.locator(".weui-desktop-dialog button:has-text('继续插入')").first.click()`。

### 坑 2：禁止使用 `document.execCommand('insertHTML', ...)` 兜底

为绕过"空粘贴"而改用 `insertHTML` 直接塞 DOM，**会绕过微信 paste 事件处理器**，导致微信的样式归一化把内联 `background-color` 洗掉（表现为"上半有背景下半白"或整体无背景）。手动 Cmd+V 能保留样式，就是因为走的是真正的 paste 事件。

→ 主粘贴必须是**真实剪贴板粘贴**（走微信 paste 处理器 + 点「继续插入」）。`insertHTML` 不得作为兜底。

### 坑 3：真实剪贴板粘贴需要 Chrome 前台焦点

`navigator.clipboard.write` + 派发 Cmd+V 依赖系统剪贴板。macOS 安全策略：**非前台（非激活）App 读不到剪贴板**，导致正文空粘贴（`len:8`，但标题用 `keyboard.type` 因走 CDP 直注反而能填）。

→ 粘贴前用 `activate_chrome()`（AppleScript `tell application "Google Chrome" to activate`）+ `edit.bring_to_front()` 强制窗口前台，再写剪贴板、再 Cmd+V。

### 坑 4：图片走真实文件上传，绕过 base64 风控

微信对「合成 ClipboardEvent 派发 base64 图」会风控拦截。正确做法：
1. 导出 `wf.html` 中的 base64 图为本地文件（`Pillow` 解码）。
2. 用 `%%IMG{i}%%` 占位段落替换图片位置。
3. 整篇文本粘贴后，在每个占位符光标处 `input[type=file].set_input_files()` 真实上传（微信会上传到 mmbiz 并返回 `<img src=mmbiz>`）。

### 坑 5：草稿箱 SPA 导航不稳定，勿自动化清理

草稿箱（`type=77&action=list_card`）经常返回"暂无素材"空态，自动化打开/删除草稿不可靠，且曾误删正确草稿。删除重复草稿交由用户手动处理。

## 发布验证清单

发布后检查 `/tmp/publish.log`：
- `[clicked 「继续插入」]` 出现（坑 1 已处理）。
- `paste via real clipboard: len>200 h2>0`。
- `heading bgs: ["rgba(0, 119, 182, 0.08)" × N]` 全部存在（背景已保留）。
- `mmbiz: N`（图片全部上传）、封面/原创/来源 `OK`、最后 `[DONE]`。

详细代码与命令见 `references/publish_workflow.md`。
